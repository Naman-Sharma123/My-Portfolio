import React from 'react';
import { motion } from 'framer-motion';
import { Github, ExternalLink, Code2, Layers } from 'lucide-react';

const projects = [
  {
    title: "Algorithm Visualizer",
    stack: ["HTML", "CSS", "JavaScript", "Sorting Algorithms"],
    bullets: [
      "Built an interactive web tool to visualize sorting algorithms (Bubble, Merge, Quick) in real-time using vanilla JavaScript and CSS animations.",
      "Designed intuitive UI controls (speed, array size) improving comprehension for 30+ users."
    ],
    github: "https://github.com/Naman-Sharma123/Algorithm_Visualizer",
    color: "from-blue-500/10 to-blue-600/10"
  },
  {
    title: "Real-time Chat App",
    stack: ["React.js", "Node.js", "Express", "Socket.io", "Tailwind"],
    bullets: [
      "Built a full-stack real-time chat app using React.js, Node.js, Express and Socket.io supporting multiple concurrent users.",
      "Implemented bi-directional WebSocket communication and a fully responsive Tailwind CSS UI for seamless cross device experience."
    ],
    github: "https://github.com/Naman-Sharma123/Chat-App",
    color: "from-purple-500/10 to-purple-600/10"
  },
  {
    title: "Job Portal",
    stack: ["React", "Tailwind", "Clerk", "Shadcn/UI"],
    bullets: [
      "Developed a job portal with Google OAuth (Clerk) supporting role-based interfaces for job seekers and recruiters.",
      "Implemented real-time application tracking with dynamic filtering and a responsive UI using React.js, Tailwind CSS and Shadcn/UI."
    ],
    github: "https://github.com/Naman-Sharma123/hirrd",
    color: "from-emerald-500/10 to-emerald-600/10"
  }
];

export const Projects: React.FC = () => {
  return (
    <section id="projects" className="relative px-6 py-32">
      <div className="mx-auto max-w-6xl">
        <motion.div
          initial={{ opacity: 0, x: -20 }}
          whileInView={{ opacity: 1, x: 0 }}
          viewport={{ once: true }}
          className="mb-16 flex items-center gap-4"
        >
          <div className="flex h-12 w-12 items-center justify-center rounded-2xl bg-blue-500/10 text-blue-400">
            <Layers size={24} />
          </div>
          <div>
            <h2 className="text-3xl font-bold tracking-tight text-white sm:text-4xl">Featured Projects</h2>
            <p className="text-sm font-mono text-blue-400/60 uppercase tracking-widest">Building the Future</p>
          </div>
        </motion.div>

        <div className="grid gap-8 md:grid-cols-2 lg:grid-cols-3">
          {projects.map((project, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: index * 0.1 }}
              whileHover={{ y: -10 }}
              className={`group relative flex flex-col overflow-hidden rounded-3xl border border-white/5 bg-gradient-to-br ${project.color} p-8 backdrop-blur-xl transition-all hover:border-white/20`}
            >
              <div className="mb-6 flex items-center justify-between">
                <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-white/5 text-white/60">
                  <Code2 size={20} />
                </div>
                <div className="flex gap-4">
                  <a href={project.github} target="_blank" className="text-white/40 hover:text-white transition-colors">
                    <Github size={20} />
                  </a>
                </div>
              </div>

              <h3 className="mb-4 text-2xl font-bold text-white">{project.title}</h3>
              
              <div className="mb-6 flex flex-wrap gap-2">
                {project.stack.map((tech, tIndex) => (
                  <span key={tIndex} className="rounded-full bg-white/5 px-3 py-1 text-[10px] font-bold uppercase tracking-widest text-blue-400/80">
                    {tech}
                  </span>
                ))}
              </div>

              <ul className="mb-8 flex-grow space-y-4">
                {project.bullets.map((bullet, bIndex) => (
                  <li key={bIndex} className="flex items-start gap-3 text-sm text-white/60 leading-relaxed">
                    <div className="mt-1.5 h-1 w-1 shrink-0 rounded-full bg-blue-500/40" />
                    {bullet}
                  </li>
                ))}
              </ul>

              <a
                href={project.github}
                target="_blank"
                className="flex items-center justify-center gap-2 rounded-2xl bg-white/5 py-3 text-sm font-bold text-white transition-all hover:bg-white/10"
              >
                View Source
                <ExternalLink size={14} />
              </a>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
};
