import React, { useEffect, useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';

export const Splash: React.FC<{ onComplete: () => void }> = ({ onComplete }) => {
  const [progress, setProgress] = useState(0);

  useEffect(() => {
    const interval = setInterval(() => {
      setProgress((prev) => {
        if (prev >= 100) {
          clearInterval(interval);
          setTimeout(onComplete, 500);
          return 100;
        }
        return prev + 2;
      });
    }, 20);
    return () => clearInterval(interval);
  }, [onComplete]);

  return (
    <motion.div
      className="fixed inset-0 z-50 flex flex-col items-center justify-center bg-[#020205] text-white"
      initial={{ opacity: 1 }}
      exit={{ opacity: 0, transition: { duration: 0.8, ease: "easeInOut" } }}
    >
      <motion.div
        className="relative mb-8 flex h-24 w-24 items-center justify-center border-2 border-blue-500/30 rounded-full"
        initial={{ scale: 0.8, opacity: 0 }}
        animate={{ scale: 1, opacity: 1 }}
        transition={{ duration: 0.5 }}
      >
        <span className="text-4xl font-bold tracking-tighter text-blue-400">NS</span>
        <motion.div
          className="absolute inset-0 rounded-full border-t-2 border-blue-400"
          animate={{ rotate: 360 }}
          transition={{ repeat: Infinity, duration: 2, ease: "linear" }}
        />
      </motion.div>

      <div className="w-64 overflow-hidden rounded-full bg-white/5 h-1">
        <motion.div
          className="h-full bg-blue-500"
          initial={{ width: 0 }}
          animate={{ width: `${progress}%` }}
          transition={{ ease: "linear" }}
        />
      </div>
      <motion.p
        className="mt-4 text-xs font-mono tracking-widest text-blue-400/60 uppercase"
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
      >
        Initializing Portfolio System... {progress}%
      </motion.p>
    </motion.div>
  );
};
