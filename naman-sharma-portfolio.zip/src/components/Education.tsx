import React from 'react';
import { motion } from 'framer-motion';
import { GraduationCap, Award, ShieldCheck } from 'lucide-react';

const education = [
  {
    institution: "SRM University",
    degree: "Bachelor of Technology - BTech, Computer Science",
    dates: "2022 - 2026",
    icon: <GraduationCap size={24} />,
    color: "text-blue-400"
  }
];

const certifications = [
  "Deloitte Australia - Data Analytics Job Simulation",
  "The Full Stack Web Development"
];

export const Education: React.FC = () => {
  return (
    <section className="relative px-6 py-32">
      <div className="mx-auto max-w-6xl">
        <div className="grid gap-12 lg:grid-cols-2">
          {/* Education */}
          <div>
            <motion.div
              initial={{ opacity: 0, x: -20 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              className="mb-12 flex items-center gap-4"
            >
              <div className="flex h-12 w-12 items-center justify-center rounded-2xl bg-blue-500/10 text-blue-400">
                <GraduationCap size={24} />
              </div>
              <div>
                <h2 className="text-3xl font-bold tracking-tight text-white sm:text-4xl">Education</h2>
                <p className="text-sm font-mono text-blue-400/60 uppercase tracking-widest">Academic Journey</p>
              </div>
            </motion.div>

            <div className="space-y-6">
              {education.map((edu, index) => (
                <motion.div
                  key={index}
                  initial={{ opacity: 0, y: 20 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  className="group relative overflow-hidden rounded-3xl border border-white/5 bg-white/5 p-8 backdrop-blur-xl transition-all hover:border-white/10 hover:bg-white/[0.07]"
                >
                  <div className="mb-4 flex items-center justify-between">
                    <h3 className="text-xl font-bold text-white">{edu.institution}</h3>
                    <span className="text-sm font-medium text-blue-400/60">{edu.dates}</span>
                  </div>
                  <p className="text-lg font-medium text-blue-100/60 leading-relaxed">{edu.degree}</p>
                </motion.div>
              ))}
            </div>
          </div>

          {/* Certifications */}
          <div>
            <motion.div
              initial={{ opacity: 0, x: -20 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              className="mb-12 flex items-center gap-4"
            >
              <div className="flex h-12 w-12 items-center justify-center rounded-2xl bg-purple-500/10 text-purple-400">
                <ShieldCheck size={24} />
              </div>
              <div>
                <h2 className="text-3xl font-bold tracking-tight text-white sm:text-4xl">Certifications</h2>
                <p className="text-sm font-mono text-purple-400/60 uppercase tracking-widest">Verified Skills</p>
              </div>
            </motion.div>

            <div className="space-y-4">
              {certifications.map((cert, index) => (
                <motion.div
                  key={index}
                  initial={{ opacity: 0, y: 20 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  transition={{ delay: index * 0.1 }}
                  className="group flex items-center gap-4 rounded-2xl border border-white/5 bg-white/5 p-6 backdrop-blur-xl transition-all hover:border-white/10 hover:bg-white/[0.07]"
                >
                  <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-purple-500/10 text-purple-400">
                    <Award size={20} />
                  </div>
                  <p className="text-lg font-medium text-white/80 leading-tight">{cert}</p>
                </motion.div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
