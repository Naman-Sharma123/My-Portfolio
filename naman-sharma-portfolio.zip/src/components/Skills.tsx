import React from 'react';
import { motion } from 'framer-motion';
import { Code2, Database, Layout, Server, ShieldCheck, Terminal } from 'lucide-react';

const skillGroups = [
  {
    title: "Languages",
    icon: <Terminal size={20} />,
    skills: ["JavaScript (ES6+)", "TypeScript", "HTML5/CSS3", "Java", "Python", "SQL"],
    color: "text-blue-400"
  },
  {
    title: "Frameworks & UI",
    icon: <Layout size={20} />,
    skills: ["React.js", "Node.js", "Spring Boot", "Express.js", "Tailwind CSS", "Socket.io", "Shadcn/UI"],
    color: "text-purple-400"
  },
  {
    title: "Databases",
    icon: <Database size={20} />,
    skills: ["MySQL", "SQLite", "MongoDB"],
    color: "text-amber-400"
  },
  {
    title: "Tools & Cloud",
    icon: <ShieldCheck size={20} />,
    skills: ["Git/GitHub", "VS Code", "Postman", "Cursor AI", "GitHub Actions", "AWS"],
    color: "text-emerald-400"
  },
  {
    title: "Concepts",
    icon: <Code2 size={20} />,
    skills: ["REST APIs", "OOPs", "DSA", "Responsive Design", "JWT/Auth", "Context API", "Architecture"],
    color: "text-rose-400"
  }
];

export const Skills: React.FC = () => {
  return (
    <section className="relative px-6 py-32">
      <div className="mx-auto max-w-6xl">
        <motion.div
          initial={{ opacity: 0, x: -20 }}
          whileInView={{ opacity: 1, x: 0 }}
          viewport={{ once: true }}
          className="mb-16 flex items-center gap-4"
        >
          <div className="flex h-12 w-12 items-center justify-center rounded-2xl bg-emerald-500/10 text-emerald-400">
            <Code2 size={24} />
          </div>
          <div>
            <h2 className="text-3xl font-bold tracking-tight text-white sm:text-4xl">Technical Expertise</h2>
            <p className="text-sm font-mono text-emerald-400/60 uppercase tracking-widest">The Stack</p>
          </div>
        </motion.div>

        <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-4">
          {skillGroups.map((group, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: index * 0.1 }}
              className="group relative overflow-hidden rounded-3xl border border-white/5 bg-white/5 p-8 backdrop-blur-xl transition-all hover:border-white/10 hover:bg-white/[0.07]"
            >
              <div className="mb-6 flex items-center gap-3">
                <div className={`flex h-10 w-10 items-center justify-center rounded-xl bg-white/5 ${group.color}`}>
                  {group.icon}
                </div>
                <h3 className="text-lg font-bold text-white">{group.title}</h3>
              </div>

              <div className="flex flex-wrap gap-2">
                {group.skills.map((skill, sIndex) => (
                  <span
                    key={sIndex}
                    className="rounded-full border border-white/5 bg-white/5 px-3 py-1 text-xs font-medium text-white/60 transition-colors group-hover:border-white/10 group-hover:text-white/80"
                  >
                    {skill}
                  </span>
                ))}
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
};
