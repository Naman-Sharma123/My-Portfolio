import React, { useEffect, useState } from 'react';
import { motion, useScroll, useTransform } from 'framer-motion';
import { Award, Code, Trophy, Users, Zap } from 'lucide-react';

const achievements = [
  {
    title: "LeetCode Mastery",
    context: "Solved 200+ problems demonstrating strong problem-solving skills.",
    value: 200,
    suffix: "+",
    icon: <Code size={24} />,
    color: "from-blue-500/20 to-blue-600/20"
  },
  {
    title: "HackerRank Success",
    context: "Solved 100+ problems across various domains.",
    value: 100,
    suffix: "+",
    icon: <Trophy size={24} />,
    color: "from-purple-500/20 to-purple-600/20"
  },
  {
    title: "Performance Optimization",
    context: "Improved dashboard performance across multiple internship projects.",
    value: 30,
    suffix: "%",
    icon: <Zap size={24} />,
    color: "from-amber-500/20 to-amber-600/20"
  }
];

const Counter: React.FC<{ value: number; suffix: string }> = ({ value, suffix }) => {
  const [count, setCount] = useState(0);

  useEffect(() => {
    let start = 0;
    const end = value;
    const duration = 2000;
    const increment = end / (duration / 16);

    const timer = setInterval(() => {
      start += increment;
      if (start >= end) {
        setCount(end);
        clearInterval(timer);
      } else {
        setCount(Math.floor(start));
      }
    }, 16);

    return () => clearInterval(timer);
  }, [value]);

  return (
    <span className="text-4xl font-bold tracking-tighter text-white sm:text-5xl">
      {count}{suffix}
    </span>
  );
};

export const Achievements: React.FC = () => {
  return (
    <section className="relative px-6 py-32">
      <div className="mx-auto max-w-6xl">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="mb-16 text-center"
        >
          <div className="mx-auto mb-4 flex h-12 w-12 items-center justify-center rounded-2xl bg-amber-500/10 text-amber-400">
            <Award size={24} />
          </div>
          <h2 className="text-3xl font-bold tracking-tight text-white sm:text-4xl">Impact & Achievements</h2>
          <p className="mt-2 text-sm font-mono text-amber-400/60 uppercase tracking-widest">Measurable Success</p>
        </motion.div>

        <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
          {achievements.map((ach, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, scale: 0.9 }}
              whileInView={{ opacity: 1, scale: 1 }}
              viewport={{ once: true }}
              transition={{ delay: index * 0.1 }}
              whileHover={{ y: -10 }}
              className={`group relative overflow-hidden rounded-3xl border border-white/5 bg-gradient-to-br ${ach.color} p-8 backdrop-blur-xl transition-all hover:border-white/20`}
            >
              <div className="absolute -right-10 -top-10 h-40 w-40 rounded-full bg-white/5 blur-3xl transition-all group-hover:bg-white/10" />
              
              <div className="mb-6 flex h-12 w-12 items-center justify-center rounded-2xl bg-white/10 text-white">
                {ach.icon}
              </div>

              <div className="mb-4">
                <Counter value={ach.value} suffix={ach.suffix} />
              </div>

              <h3 className="mb-2 text-xl font-bold text-white">{ach.title}</h3>
              <p className="text-sm leading-relaxed text-white/60">{ach.context}</p>
            </motion.div>
          ))}
        </div>

        {/* Top 3 Impact Strip */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="mt-16 flex flex-wrap justify-center gap-8 rounded-3xl border border-white/5 bg-white/5 p-8 backdrop-blur-md"
        >
          <div className="flex items-center gap-3">
            <div className="h-2 w-2 rounded-full bg-blue-500" />
            <span className="text-sm font-medium text-white/80">30% Efficiency Gain</span>
          </div>
          <div className="flex items-center gap-3">
            <div className="h-2 w-2 rounded-full bg-purple-500" />
            <span className="text-sm font-medium text-white/80">200+ LeetCode Solved</span>
          </div>
          <div className="flex items-center gap-3">
            <div className="h-2 w-2 rounded-full bg-amber-500" />
            <span className="text-sm font-medium text-white/80">50+ Active Dashboard Users</span>
          </div>
        </motion.div>
      </div>
    </section>
  );
};
