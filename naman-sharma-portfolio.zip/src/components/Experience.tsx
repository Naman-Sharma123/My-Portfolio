import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Briefcase, Calendar, ChevronDown, ChevronUp, ExternalLink, TrendingUp } from 'lucide-react';

const experiences = [
  {
    company: "TechSonIx Solutions",
    role: "Full Stack Developer Intern",
    dates: "June 2025 - July 2025",
    bullets: [
      "Developed and maintained responsive, user-friendly web applications using HTML, CSS, JavaScript, and React.",
      "Integrated RESTful APIs to enable dynamic data fetching and seamless frontend-backend communication.",
      "Implemented backend and database functionalities (CRUD) using Node.js/ MySQL, improving data retrieval efficiency by 30%"
    ],
    metrics: [
      { label: "Data Retrieval Efficiency", value: "30%" }
    ]
  },
  {
    company: "NeuroNexus",
    role: "Web Development Intern",
    dates: "April 2025 - May 2025",
    bullets: [
      "Built and optimized a responsive dashboard using React.js and REST APIs, reducing page load time by 30% and improving data visualization efficiency for 50+ users.",
      "Integrated RESTful APIs and managed component state to ensure seamless data flow across the dashboard.",
      "Delivered features on schedule within an Agile sprint workflow."
    ],
    metrics: [
      { label: "Page Load Time Reduction", value: "30%" },
      { label: "User Reach", value: "50+" }
    ]
  }
];

export const Experience: React.FC = () => {
  const [expanded, setExpanded] = useState<number | null>(0);

  return (
    <section id="experience" className="relative px-6 py-32">
      <div className="mx-auto max-w-4xl">
        <motion.div
          initial={{ opacity: 0, x: -20 }}
          whileInView={{ opacity: 1, x: 0 }}
          viewport={{ once: true }}
          className="mb-16 flex items-center gap-4"
        >
          <div className="flex h-12 w-12 items-center justify-center rounded-2xl bg-blue-500/10 text-blue-400">
            <Briefcase size={24} />
          </div>
          <div>
            <h2 className="text-3xl font-bold tracking-tight text-white sm:text-4xl">Professional Experience</h2>
            <p className="text-sm font-mono text-blue-400/60 uppercase tracking-widest">The Career Timeline</p>
          </div>
        </motion.div>

        <div className="space-y-6">
          {experiences.map((exp, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: index * 0.1 }}
              className={`group relative overflow-hidden rounded-3xl border transition-all duration-500 ${
                expanded === index 
                  ? "border-blue-500/30 bg-blue-500/5 backdrop-blur-xl" 
                  : "border-white/5 bg-white/5 hover:border-white/10 hover:bg-white/[0.07]"
              }`}
            >
              <button
                onClick={() => setExpanded(expanded === index ? null : index)}
                className="flex w-full items-start justify-between p-8 text-left"
              >
                <div className="flex flex-col gap-2">
                  <div className="flex items-center gap-3">
                    <h3 className="text-xl font-bold text-white sm:text-2xl">{exp.company}</h3>
                    <span className="rounded-full bg-blue-500/10 px-3 py-1 text-[10px] font-bold uppercase tracking-widest text-blue-400">
                      Internship
                    </span>
                  </div>
                  <p className="text-lg font-medium text-blue-100/60">{exp.role}</p>
                  <div className="flex items-center gap-2 text-sm text-white/40">
                    <Calendar size={14} />
                    {exp.dates}
                  </div>
                </div>
                <div className="flex h-10 w-10 items-center justify-center rounded-full bg-white/5 text-white/40 transition-colors group-hover:bg-white/10 group-hover:text-white">
                  {expanded === index ? <ChevronUp size={20} /> : <ChevronDown size={20} />}
                </div>
              </button>

              <AnimatePresence>
                {expanded === index && (
                  <motion.div
                    initial={{ height: 0, opacity: 0 }}
                    animate={{ height: "auto", opacity: 1 }}
                    exit={{ height: 0, opacity: 0 }}
                    transition={{ duration: 0.4, ease: "easeInOut" }}
                  >
                    <div className="border-t border-white/5 p-8 pt-0">
                      <div className="mt-6 flex flex-wrap gap-4">
                        {exp.metrics.map((metric, mIndex) => (
                          <div key={mIndex} className="flex items-center gap-2 rounded-2xl bg-blue-500/10 px-4 py-2 border border-blue-500/20">
                            <TrendingUp size={14} className="text-blue-400" />
                            <span className="text-xs font-bold text-blue-400">{metric.value}</span>
                            <span className="text-[10px] font-medium text-blue-100/40 uppercase tracking-wider">{metric.label}</span>
                          </div>
                        ))}
                      </div>

                      <ul className="mt-8 space-y-4">
                        {exp.bullets.map((bullet, bIndex) => (
                          <motion.li
                            key={bIndex}
                            initial={{ opacity: 0, x: -10 }}
                            animate={{ opacity: 1, x: 0 }}
                            transition={{ delay: 0.2 + bIndex * 0.1 }}
                            className="flex items-start gap-3 text-blue-100/60"
                          >
                            <div className="mt-2.5 h-1.5 w-1.5 shrink-0 rounded-full bg-blue-500/40" />
                            <span className="text-sm leading-relaxed">{bullet}</span>
                          </motion.li>
                        ))}
                      </ul>
                    </div>
                  </motion.div>
                )}
              </AnimatePresence>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
};
