import React from 'react';
import { motion } from 'framer-motion';
import { ArrowDown, Download, MapPin } from 'lucide-react';

export const Hero: React.FC = () => {
  const scrollToExperience = () => {
    document.getElementById('experience')?.scrollIntoView({ behavior: 'smooth' });
  };

  return (
    <section className="relative flex min-h-screen flex-col items-center justify-center px-6 pt-20 text-center">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.8, delay: 0.2 }}
        className="mb-4 flex items-center gap-2 rounded-full border border-blue-500/20 bg-blue-500/5 px-4 py-1.5 text-xs font-medium tracking-widest text-blue-400 uppercase"
      >
        <MapPin size={12} />
        India • Open to Roles
      </motion.div>

      <motion.h1
        className="mb-4 text-5xl font-bold tracking-tighter text-white sm:text-7xl md:text-8xl"
        initial={{ opacity: 0, y: 30 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 1, ease: "easeOut" }}
      >
        Naman <span className="text-blue-500">Sharma</span>
      </motion.h1>

      <motion.p
        className="mb-8 max-w-2xl text-lg font-light leading-relaxed text-blue-100/60 sm:text-xl"
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ duration: 1, delay: 0.5 }}
      >
        Aspiring Software Developer | Full Stack Engineer specializing in Java, Spring Boot, and React.js. 
        Passionate about building scalable, high-performance web applications.
      </motion.p>

      <motion.div
        className="flex flex-col items-center gap-4 sm:flex-row"
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.8, delay: 0.8 }}
      >
        <button
          onClick={scrollToExperience}
          className="group relative flex items-center gap-2 overflow-hidden rounded-full bg-blue-600 px-8 py-4 font-semibold text-white transition-all hover:bg-blue-500 active:scale-95"
        >
          View Experience
          <ArrowDown size={18} className="transition-transform group-hover:translate-y-1" />
        </button>

        <a
          href="/resume.pdf"
          target="_blank"
          className="flex items-center gap-2 rounded-full border border-white/10 bg-white/5 px-8 py-4 font-semibold text-white backdrop-blur-sm transition-all hover:bg-white/10 active:scale-95"
        >
          Download Resume
          <Download size={18} />
        </a>
      </motion.div>

      <motion.div
        className="absolute bottom-10 left-1/2 -translate-x-1/2"
        animate={{ y: [0, 10, 0] }}
        transition={{ repeat: Infinity, duration: 2 }}
      >
        <div className="h-12 w-6 rounded-full border-2 border-white/10 p-1">
          <div className="h-2 w-full rounded-full bg-blue-500/50" />
        </div>
      </motion.div>
    </section>
  );
};
