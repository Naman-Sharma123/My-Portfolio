/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { AnimatePresence, motion } from 'framer-motion';
import { Splash } from './components/Splash';
import { AnimatedBackground } from './components/AnimatedBackground';
import { Navbar } from './components/Navbar';
import { Hero } from './components/Hero';
import { Experience } from './components/Experience';
import { Achievements } from './components/Achievements';
import { Skills } from './components/Skills';
import { Education } from './components/Education';
import { Projects } from './components/Projects';
import { Mail, Linkedin, Github, ExternalLink } from 'lucide-react';

export default function App() {
  const [showSplash, setShowSplash] = useState(true);

  return (
    <div className="relative min-h-screen bg-[#020205] font-sans selection:bg-blue-500/30 selection:text-blue-200">
      <AnimatePresence mode="wait">
        {showSplash ? (
          <Splash key="splash" onComplete={() => setShowSplash(false)} />
        ) : (
          <motion.main
            key="main"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 1 }}
            className="relative"
          >
            <AnimatedBackground />
            <Navbar />
            
            <div className="mx-auto max-w-7xl">
              <Hero />
              
              <div id="achievements">
                <Achievements />
              </div>

              <div id="projects">
                <Projects />
              </div>

              <div id="experience">
                <Experience />
              </div>

              <div id="skills">
                <Skills />
              </div>

              <div id="education">
                <Education />
              </div>

              {/* Footer */}
              <footer className="relative border-t border-white/5 px-6 py-20 text-center">
                <motion.div
                  initial={{ opacity: 0, y: 20 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  className="mx-auto max-w-2xl"
                >
                  <h2 className="mb-6 text-3xl font-bold tracking-tight text-white sm:text-4xl">Let's Build the Future Together</h2>
                  <p className="mb-10 text-lg text-blue-100/40 leading-relaxed">
                    Currently seeking full stack or software developer roles in India or remotely. 
                    Let's connect and discuss how I can contribute to your team.
                  </p>
                  
                  <div className="flex flex-wrap justify-center gap-6">
                    <a
                      href="mailto:naman.sh.fzd@gmail.com"
                      className="flex items-center gap-3 rounded-2xl border border-white/5 bg-white/5 px-8 py-4 font-semibold text-white transition-all hover:bg-white/10 hover:border-white/20 active:scale-95"
                    >
                      <Mail size={20} className="text-blue-400" />
                      naman.sh.fzd@gmail.com
                    </a>
                    <a
                      href="https://www.linkedin.com/in/naman-sharma-09a32924b"
                      target="_blank"
                      className="flex items-center gap-3 rounded-2xl border border-white/5 bg-white/5 px-8 py-4 font-semibold text-white transition-all hover:bg-white/10 hover:border-white/20 active:scale-95"
                    >
                      <Linkedin size={20} className="text-blue-400" />
                      LinkedIn Profile
                    </a>
                  </div>

                  <div className="mt-20 flex flex-col items-center justify-between gap-6 border-t border-white/5 pt-10 sm:flex-row">
                    <span className="text-sm font-medium text-white/20 tracking-tighter">
                      © 2026 NAMAN SHARMA<span className="text-blue-500">.</span> ALL RIGHTS RESERVED
                    </span>
                    <div className="flex gap-6">
                      <span className="text-[10px] font-mono text-white/10 uppercase tracking-widest">
                        Built with React + Framer Motion + Tailwind
                      </span>
                    </div>
                  </div>
                </motion.div>
              </footer>
            </div>
          </motion.main>
        )}
      </AnimatePresence>
    </div>
  );
}
